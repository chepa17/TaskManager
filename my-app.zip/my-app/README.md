Project Description
You have to develop a task manager using design mockups provided with this task. 

User should be able to:

- add a task (either clicking non “Add” or by pressing Enter)

- complete a task by checking up the checkbox

- when task is complete, user should see the completion date

- un-complete a task by un checking the checkbox, in which case the completion date should
be hidden

- when user refresh a browser window all completed tasks should be removed and not
displayed anymore

- all completed tasks should be also automatically removed after 1 minute of completion time

- when the task is marked as completed it should be moved to the end of the list, where all
completed tasks should be ordered by completion time